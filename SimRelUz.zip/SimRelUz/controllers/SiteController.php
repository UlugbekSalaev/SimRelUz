<?php

namespace app\controllers;

use app\models\Quetion;
use app\models\Rating;
use Symfony\Component\Console\Question\Question;
use Yii;
use yii\filters\AccessControl;
use yii\helpers\VarDumper;
use yii\web\Controller;
use yii\web\Response;
use yii\filters\VerbFilter;
use app\models\LoginForm;
use app\models\ContactForm;
use yii\web\ErrorAction;
use yii\captcha\CaptchaAction;
use yii\db\Expression;

class SiteController extends Controller
{
    /**
     * {@inheritdoc}
     */
    public function behaviors(): array
    {
        return [
            'access' => [
                'class' => AccessControl::class,
                'only' => ['logout', 'index', 'about', 'contact'],
                'rules' => [
                    [
                        'actions' => ['logout', 'index', 'about', 'contact'],
                        'allow' => true,
                        'roles' => ['@'],
                    ],
                ],
            ],
            'verbs' => [
                'class' => VerbFilter::class,
                'actions' => [
                    'logout' => ['post'],
                ],
            ],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function actions(): array
    {
        return [
            'error' => [
                'class' => ErrorAction::class,
            ],
            'captcha' => [
                'class' => CaptchaAction::class,
                'fixedVerifyCode' => YII_ENV_TEST ? 'testme' : null,
            ],
        ];
    }

    /**
     * Displays homepage.
     *
     * @return string|Response
     */
    public function actionIndex(): Response|string
    {
        $model = new Rating();
        $model->user_id = Yii::$app->user->identity->id;
        if ($this->request->isPost && $model->load($this->request->post())) {
            if ($model->save()) {
                return $this->redirect(['index']);
            }
        }
        $ids = Rating::find()->select(['quetion_id'])->groupBy(['quetion_id'])->where(['user_id'=>$model->user_id])->column();
	//print_r($ids);        
	$question = Quetion::find()->where(['not in', 'id', $ids])->orderBy('random()')->limit(1)->one();
	//print_r($question);
        //exit();
 //       $stat = [
 //           'sim' => Rating::find()->select(['sim_bal'])->andFilterWhere(['quetion_id' => $question->id])->average('sim_bal') ?: "Hali baholanmagan",
 //           'rel' => Rating::find()->select(['rel_bal'])->andFilterWhere(['quetion_id' => $question->id])->average('rel_bal') ?: "Hali bahonlanmagan",
 //           'sim_bals' => implode(', ', array_column(Rating::find()->select(['sim_bal'])->andFilterWhere(['quetion_id' => $question->id])->limit(3)->asArray()->all(), 'sim_bal')),
 //           'rel_bals' => implode(', ', array_column(Rating::find()->select(['rel_bal'])->andFilterWhere(['quetion_id' => $question->id])->limit(3)->asArray()->all(), 'rel_bal'))
 //       ];
//        var_dump($data);
//        exit();
	if(!$question) 
		return $this->render('index', [
        	    'model' => null
	        ]);
        else {
	$model->quetion_id = $question->id;
        return $this->render('index', [
            'model' => $model,
            'question' => $question,
            
        ]);//'stat'=>$stat
	}					
    }

    /**
     * Login action.
     *
     * @return Response|string
     */
    public function actionLogin(): Response|string
    {
        if (!Yii::$app->user->isGuest) {
            return $this->goHome();
        }

        $model = new LoginForm();
        if ($model->load(Yii::$app->request->post()) && $model->login()) {
            return $this->goBack();
        }

        $model->password = '';
        return $this->render('login', [
            'model' => $model,
        ]);
    }

    /**
     * Logout action.
     *
     * @return Response
     */
    public function actionLogout()
    {
        Yii::$app->user->logout();

        return $this->goHome();
    }

    /**
     * Displays contact page.
     *
     * @return Response|string
     */
    public function actionContact(): Response|string
    {
        $model = new ContactForm();
        if ($model->load(Yii::$app->request->post()) && $model->contact(Yii::$app->params['adminEmail'])) {
            Yii::$app->session->setFlash('contactFormSubmitted');

            return $this->refresh();
        }
        return $this->render('contact', [
            'model' => $model,
        ]);
    }

    /**
     * Displays about page.
     *
     * @return string
     */
    public function actionAbout()
    {
        return $this->render('about');
    }
}
