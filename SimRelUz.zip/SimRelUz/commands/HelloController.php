<?php
/**
 * @link http://www.yiiframework.com/
 * @copyright Copyright (c) 2008 Yii Software LLC
 * @license http://www.yiiframework.com/license/
 */

namespace app\commands;

use app\models\User;
use yii\console\Controller;
use yii\console\ExitCode;

/**
 * This command echoes the first argument that you have entered.
 *
 * This command is provided as an example for you to learn how to create console commands.
 *
 * @author Qiang Xue <qiang.xue@gmail.com>
 * @since 2.0
 */
class HelloController extends Controller
{
    /**
     * This command echoes what you have entered as the message.
     * @param string $message the message to be echoed.
     * @return int Exit code
     */
    public function actionIndex($message = 'hello world')
    {
        echo $message . "\n";

        return ExitCode::OK;
    }

    public function actionAddUsers(): int
    {
        $items = [
            ['name' => 'user2', 'login' => 'user2', 'password' => 'user2'],
            ['name' => 'user3', 'login' => 'user3', 'password' => 'user3'],
            ['name' => 'user4', 'login' => 'user4', 'password' => 'user4'],
            ['name' => 'user5', 'login' => 'user5', 'password' => 'user5'],
            ['name' => 'user6', 'login' => 'user6', 'password' => 'user6'],
            ['name' => 'user7', 'login' => 'user7', 'password' => 'user7'],
            ['name' => 'user8', 'login' => 'user8', 'password' => 'user8'],
            ['name' => 'user9', 'login' => 'user9', 'password' => 'user9'],
            ['name' => 'user10', 'login' => 'user10', 'password' => 'user10'],
            ['name' => 'user11', 'login' => 'user11', 'password' => 'user11'],
            ['name' => 'user12', 'login' => 'user12', 'password' => 'user12'],
            ['name' => 'user13', 'login' => 'user13', 'password' => 'user13'],
            ['name' => 'user14', 'login' => 'user14', 'password' => 'user14'],
            ['name' => 'user15', 'login' => 'user15', 'password' => 'user15'],
            ['name' => 'user16', 'login' => 'user16', 'password' => 'user16'],
            ['name' => 'user17', 'login' => 'user17', 'password' => 'user17'],
            ['name' => 'user18', 'login' => 'user18', 'password' => 'user18'],
            ['name' => 'user19', 'login' => 'user19', 'password' => 'user19'],
            ['name' => 'user20', 'login' => 'user20', 'password' => 'user20'],
        ];
        foreach ($items as $item) {
            $user = new User();
            $user->username = $item['login'];
            $user->name = $item['name'];
            $user->password = $item['password'];
            $user->save();
        }
        return ExitCode::OK;
    }
}
