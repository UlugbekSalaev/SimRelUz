<?php

namespace app\models;

use app\models\query\RatingQuery;
use Yii;

/**
 * This is the model class for table "rating".
 *
 * @property int $id
 * @property int|null $sim_bal
 * @property int|null $rel_bal
 * @property int|null $user_id
 * @property int|null $quetion_id
 *
 * @property Quetion $quetion
 * @property User $user
 */
class Rating extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'rating';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['sim_bal', 'rel_bal', 'user_id', 'quetion_id'], 'integer'],
            [['sim_bal', 'rel_bal', 'user_id', 'quetion_id'], 'required'],
            [['user_id', 'quetion_id'], 'unique', 'targetAttribute' => ['user_id', 'quetion_id']],
            [['quetion_id'], 'exist', 'skipOnError' => true, 'targetClass' => Quetion::class, 'targetAttribute' => ['quetion_id' => 'id']],
            [['user_id'], 'exist', 'skipOnError' => true, 'targetClass' => User::class, 'targetAttribute' => ['user_id' => 'id']],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'sim_bal' => 'Sim Bal',
            'rel_bal' => 'Rel Bal',
            'user_id' => 'User ID',
            'quetion_id' => 'Quetion ID',
        ];
    }

    /**
     * Gets query for [[Quetion]].
     *
     * @return \yii\db\ActiveQuery|\app\models\query\QuetionQuery
     */
    public function getQuetion()
    {
        return $this->hasOne(Quetion::className(), ['id' => 'quetion_id']);
    }

    /**
     * Gets query for [[User]].
     *
     * @return \yii\db\ActiveQuery|\app\models\query\UserQuery
     */
    public function getUser()
    {
        return $this->hasOne(User::className(), ['id' => 'user_id']);
    }

    /**
     * {@inheritdoc}
     * @return RatingQuery the active query used by this AR class.
     */
    public static function find()
    {
        return new RatingQuery(static::class);
    }
}
