<?php

namespace app\models\search;

use app\models\education\TBackups;
use app\models\hemis\HLessonPair;
use app\models\Quetion;
use app\models\User;
use PhpOffice\PhpSpreadsheet\Cell\DataType;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use Yii;
use yii\base\Model;
use yii\data\ActiveDataProvider;
use app\models\Rating;
use yii\helpers\ArrayHelper;
use yii\helpers\FileHelper;

/**
 * RatingSearch represents the model behind the search form of `app\models\Rating`.
 */
class RatingSearch extends Rating
{
    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['id', 'sim_bal', 'rel_bal', 'user_id', 'quetion_id'], 'integer'],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function scenarios()
    {
        // bypass scenarios() implementation in the parent class
        return Model::scenarios();
    }

    /**
     * Creates data provider instance with search query applied
     *
     * @param array $params
     *
     * @return ActiveDataProvider
     */
    public function search($params)
    {
        $query = Rating::find();

        // add conditions that should always apply here

        $dataProvider = new ActiveDataProvider([
            'query' => $query,
        ]);

        $this->load($params);

        if (!$this->validate()) {
            // uncomment the following line if you do not want to return any records when validation fails
            // $query->where('0=1');
            return $dataProvider;
        }

        // grid filtering conditions
        $query->andFilterWhere([
            'id' => $this->id,
            'sim_bal' => $this->sim_bal,
            'rel_bal' => $this->rel_bal,
            'user_id' => $this->user_id,
            'quetion_id' => $this->quetion_id,
        ]);

        return $dataProvider;
    }

    public function toExport(?\yii\db\QueryInterface $query): string
    {
        $speadsheet = new Spreadsheet();
        $sheet = $speadsheet->getActiveSheet();

        $title = 'export';
        $sheet->setTitle(substr($title, 0, 31));
        $row = 1;
        $col = 1;

        $model = Quetion::find()->all();
        $sheet->setCellValueExplicitByColumnAndRow($col++, $row, '#', DataType::TYPE_STRING);
        $sheet->setCellValueExplicitByColumnAndRow($col++, $row, 'Word 1', DataType::TYPE_STRING);
        $sheet->setCellValueExplicitByColumnAndRow($col++, $row, 'Word 2', DataType::TYPE_STRING);
        $sheet->setCellValueExplicitByColumnAndRow($col++, $row, 'Pos', DataType::TYPE_STRING);
        $sheet->setCellValueExplicitByColumnAndRow($col++, $row, 'Frq', DataType::TYPE_STRING);
        $sheet->setCellValueExplicitByColumnAndRow($col++, $row, 'Type', DataType::TYPE_STRING);
        $sheet->setCellValueExplicitByColumnAndRow($col++, $row, 'Level', DataType::TYPE_STRING);
        $user = User::find()->orderBy(['id' => SORT_ASC])->all();
        foreach ($user as $item) {
            $sheet->setCellValueExplicitByColumnAndRow($col++, $row, 'Sim bal ('.$item->id.')', DataType::TYPE_STRING);
            $sheet->setCellValueExplicitByColumnAndRow($col++, $row, 'Rel bal ('.$item->id.')', DataType::TYPE_STRING);
        }

        foreach ($model as $key => $item) {
            $row++;
            $col = 1;
            $sheet->setCellValueExplicitByColumnAndRow($col++, $row, $item->id, DataType::TYPE_STRING);
            $sheet->setCellValueExplicitByColumnAndRow($col++, $row, $item->w1, DataType::TYPE_STRING);
            $sheet->setCellValueExplicitByColumnAndRow($col++, $row, $item->w2, DataType::TYPE_STRING);
            $sheet->setCellValueExplicitByColumnAndRow($col++, $row, $item->pos, DataType::TYPE_STRING);
            $sheet->setCellValueExplicitByColumnAndRow($col++, $row, $item->frq, DataType::TYPE_STRING);
            $sheet->setCellValueExplicitByColumnAndRow($col++, $row, $item->type, DataType::TYPE_STRING);
            $sheet->setCellValueExplicitByColumnAndRow($col++, $row, $item->level, DataType::TYPE_STRING);
//            $sheet->setCellValueExplicitByColumnAndRow($col++, $row, $item->sim_bal, DataType::TYPE_STRING);
//            $sheet->setCellValueExplicitByColumnAndRow($col++, $row, $item->rel_bal, DataType::TYPE_STRING);
//            $sheet->setCellValueExplicitByColumnAndRow($col++, $row, $item->user_id, DataType::TYPE_STRING);
            $user = User::find()->orderBy(['id' => SORT_ASC])->all();
            foreach ($user as $value) {
                $rating = Rating::find()->where(['quetion_id' => $item->id, 'user_id' => $value->id])->one();
                $sheet->setCellValueExplicitByColumnAndRow($col++, $row, @$rating->sim_bal, DataType::TYPE_STRING);
                $sheet->setCellValueExplicitByColumnAndRow($col++, $row, @$rating->rel_bal, DataType::TYPE_STRING);
            }

        }
        $name = 'export-' . time() . '.xlsx';
        $writer = new Xlsx($speadsheet);

        $dir = Yii::$app->basePath . '/runtime/export';
        if (!is_dir($dir)) {
            FileHelper::createDirectory($dir, 0777);
        }
        $fileName = $dir . DIRECTORY_SEPARATOR . $name;
        $writer->save($fileName);
        return $fileName;
    }
}
