<?php

namespace app\models;

use app\models\query\QuetionQuery;
use Yii;

/**
 * This is the model class for table "quetion".
 *
 * @property int $id
 * @property string|null $w1
 * @property string|null $w2
 * @property string|null $pos
 * @property string|null $frq
 * @property string|null $type
 * @property string|null $level
 *
 * @property Rating[] $ratings
 */
class Quetion extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'quetion';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['w1', 'w2'], 'string', 'max' => 255],
            [['pos', 'type','frq','level'], 'string', 'max' => 40],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'w1' => 'W 1',
            'w2' => 'W 2',
            'sim' => 'Sim',
            'rel' => 'Rel',
        ];
    }

    /**
     * Gets query for [[Ratings]].
     *
     * @return \yii\db\ActiveQuery|\app\models\query\RatingQuery
     */
    public function getRatings()
    {
        return $this->hasMany(Rating::class, ['quetion_id' => 'id']);
    }

    /**
     * {@inheritdoc}
     * @return QuetionQuery the active query used by this AR class.
     */
    public static function find(): QuetionQuery
    {
        return new QuetionQuery(modelClass: get_called_class());
    }
}
