<?php

namespace app\models;

use app\models\query\QuetionQuery;
use app\models\query\RatingQuery;
use app\models\query\UserQuery;
use phpDocumentor\Reflection\Types\String_;
use Yii;
use yii\base\InvalidConfigException;
use yii\db\ActiveQuery;
use yii\web\IdentityInterface;

/**
 * This is the model class for table "user".
 *
 * @property int $id
 * @property string $name
 * @property string $username
 * @property string $password
 *
 * @property Quetion[] $quetions
 * @property Rating[] $ratings
 */
class User extends \yii\db\ActiveRecord implements IdentityInterface
{
    /**
     * {@inheritdoc}
     */
    public static function tableName(): string
    {
        return 'user';
    }

    /**
     * {@inheritdoc}
     */
    public function rules(): array
    {
        return [
            [['name', 'username', 'password'], 'required'],
            [['name', 'username', 'password'], 'string', 'max' => 255],
            [['username'], 'unique'],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'name' => 'Name',
            'username' => 'Username',
            'password' => 'Password',
        ];
    }

    /**
     * Gets query for [[Quetions]].
     *
     * @return ActiveQuery|QuetionQuery
     * @throws InvalidConfigException
     */
    public function getQuetions(): ActiveQuery|QuetionQuery
    {
        return $this->hasMany(Quetion::class, ['id' => 'quetion_id'])->viaTable('rating', ['user_id' => 'id']);
    }

    /**
     * Gets query for [[Ratings]].
     *
     * @return ActiveQuery|RatingQuery
     */
    public function getRatings(): ActiveQuery|RatingQuery
    {
        return $this->hasMany(Rating::class, ['user_id' => 'id']);
    }

    /**
     * {@inheritdoc}
     * @return UserQuery the active query used by this AR class.
     */
    public static function find()
    {
        return new UserQuery(static::class);
    }

    public static function findIdentity($id)
    {
        return self::findOne(['id' => $id]);
    }

    public static function findIdentityByAccessToken($token, $type = null)
    {
        // TODO: Implement findIdentityByAccessToken() method.
    }

    public function getId()
    {
        return $this->id;
    }

    public function getAuthKey()
    {
        return 'salom';
    }

    public function validateAuthKey($authKey)
    {
        return true;
    }

    public static function findByUsername(string $username)
    {
        return self::findOne(['username' => $username]);
    }

    public function validatePassword(string $password): bool
    {
        return $this->password === $password;
    }
}
