<?php

use app\models\Rating;
use yii\helpers\Html;
use yii\helpers\Url;
use yii\grid\ActionColumn;
use yii\grid\GridView;
use yii\widgets\Pjax;

/* @var $this yii\web\View */
/* @var $searchModel app\models\search\RatingSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Ratings';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="rating-index">

    <h1><?= Html::encode($this->title) ?></h1>
    <p>
        <?=Html::beginForm()?>
        <?=Html::submitButton('Export',['class'=>'btn btn-primary'])?>
        <?=Html::endForm()?>
    </p>

    <?php Pjax::begin(); ?>
    <?php // echo $this->render('_search', ['model' => $searchModel]); ?>

    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],

            'id',
            [
                'attribute' => 'quetion_id',
                'label' => 'Questions',
                'value' => function (Rating $rating) {
                    return @$rating->quetion->w1 . '-' . @$rating->quetion->w2;
                }
            ],
            [
                'label' => 'Pos',
                'value' => function (Rating $rating) {
                    return @$rating->quetion->pos;
                }
            ],
            [
                'label' => 'Frq',
                'value' => function (Rating $rating) {
                    return @$rating->quetion->frq;
                }
            ],
            [
                'label' => 'Level',
                'value' => function (Rating $rating) {
                    return @$rating->quetion->level;
                }
            ],
            [
                'label' => 'Type',
                'value' => function (Rating $rating) {
                    return @$rating->quetion->type;
                }
            ],



            'sim_bal',
            'rel_bal',
            [
                    'attribute' => 'user_id',
                'value' => function (Rating $rating) {
                    return @$rating->user->name;
                }
            ],

            [
                'class' => ActionColumn::class,
                'urlCreator' => function ($action, Rating $model, $key, $index, $column) {
                    return Url::toRoute([$action, 'id' => $model->id]);
                }
            ],
        ],
    ]); ?>

    <?php Pjax::end(); ?>
			<table class="col-md-3 table table-sm table-hover">
			<?php for ($i=1; $i<=15; $i++){
				$x=Rating::find()->where(['user_id'=>$i])->count();
				echo "<tr><td>user".$i."</td><td>".$x."</td><td>".Round($x/1418*100)."%</td></tr>";
			}
			?>
   			</table>
</div>
