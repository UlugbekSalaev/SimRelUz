<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model app\models\Quetion */

$this->title = 'Create Quetion';
$this->params['breadcrumbs'][] = ['label' => 'Quetions', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="quetion-create">

    <h1><?= Html::encode($this->title) ?></h1>

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
