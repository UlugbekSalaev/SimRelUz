<?php

/** @var yii\web\View $this */

/** @var Rating $model */
/** @var array $stat */

/** @var Quetion $question */

use app\models\Quetion;
use app\models\Rating;
use app\models\User;
use yii\bootstrap4\ActiveForm;
use yii\helpers\Html;

$this->title = 'SimRel';
$data = [
    0 => 0,
    1 => 1,
    2 => 2,
    3 => 3,
    4 => 4,
    5 => 5,
    6 => 6,
    7 => 7,
    8 => 8,
    9 => 9,
    10 => 10,
];
?>
<div class="site-index">


    <div class="body-content row">

        <?php $form = ActiveForm::begin(); 
		if(!$model) {echo "Siz tugatdingiz! <a href='https://simrel.urdu.uz/rating/index'>Qaytish</a>"; exit();}
	?>
        <table class="table">
            <tr>
                <th colspan="2">
                    <h1><?= $question->w1 . ' -- ' . $question->w2 ?></h1>
                </th>
            </tr>
            <tr>
                <td width="55%">
                    <?= $form->field($model, 'sim_bal',['inputOptions' => ['tabindex' => '-1']])->inline()->radioList($data)->label("<b>O'xshashlik</b>") ?>
                    <!--
                    O'xshashlik    
	   	    <select class="form-select form-select-lg mb-3" name="Rating[sim_bal]" style="width:300px" autofocus required>
			  <option style="display:none" value="">----</option>
			  <option value="0">0</option>
			  <option value="1">1</option>
			  <option value="2">2</option>
			  <option value="3">3</option>
			  <option value="4">4</option>
			  <option value="5">5</option>
			  <option value="6">6</option>
			  <option value="7">7</option>
			  <option value="8">8</option>
			  <option value="9">9</option>
			  <option value="10">10</option>
		   </select>-->
		   <!--<input type="number" min=0 max=10 step=1 name="Rating[sim_bal]" style="width:300px" autofocus required id="sim">-->
		    <br>
                    <hr>
                    <?= $form->field($model, 'rel_bal',['inputOptions' => ['tabindex' => '-1']])->inline()->radioList($data)->label("<b>Bog'liqlik</b>") ?>
		    <!--
                    Bog'liqlik &nbsp;&nbsp;&nbsp;
		    <select class="form-select form-select-lg mb-3" name="Rating[rel_bal]" style="width:300px" required>
			  <option style="display:none" value="">----</option>
			  <option value="0">0</option>
			  <option value="1">1</option>
			  <option value="2">2</option>
			  <option value="3">3</option>
			  <option value="4">4</option>
			  <option value="5">5</option>
			  <option value="6">6</option>
			  <option value="7">7</option>
			  <option value="8">8</option>
			  <option value="9">9</option>
			  <option value="10">10</option>
		   </select>-->
		   <!--<input type="number" min=0 max=10 step=1 name="Rating[rel_bal]" style="width:300px" required>-->
                    <?= $form->field($model, 'quetion_id')->hiddenInput()->label(false) ?>
                    
                    <hr>
                    <?= Html::submitInput('Saqlash', ['class' => 'btn btn-info']) ?>
		    <br><br>
			<!--<?= '(' . $question->pos . ",  " . $question->type . ')' ?><br>-->
			<?=Rating::find()->where(['user_id'=>Yii::$app->user->identity->id])->count()?> / 1418 
	<!--<?php User::updateAll(['id' => '15'], ['in', 'username', ['user15']]); ?>
	<?php print_r(User::find()->all())?>-->
                </td>
                <td >
                    <h3>Yo’riqnoma:</h3>
                    Sizga so’z juftliklari taqdim etiladi, va sizdan juftliklarning o’xshashlik(Similarity) va bog’liqlik(Relatedness) bo’yicha 0 dan 10 gacha ball bilan baholash so’raladi.
                    <br>
                    <b>O’xshashlik (Similarity):</b> Nisbatan bir-biriga yaqin, yoki aynan bir xil bo’lgan narsa, voqea yoki holatni tavsiflovchi so’zlardir. Masalan: (kofe-choy), (qadah-piyola), (kalta-qisqa), (kulmoq-jilmaymoq), …
                    <br>
                    <b>Bog’liqlik(Relatedness):</b>  Aynan bir xil narsa, hodisa yoki holatni bildirmaydigan(o’xshash bo’lmagan), ammo bir sohaga tegishli, birgalikda qo’llaniluvchi, yoki so’zning ishlatilish jihatidan bir kontentda ishlatiluvchi so’zlar. Masalan: (choynak-piyola), (rang-qora), (barg-daraxt), (mashina-motor), …
                    <br>
                    <hr>
                    <!--<h3>Maslahat:</h3>
                    <b>Sinonim so’zlar:</b> O’xshashlik jihatdan eng yuqori ball bilan belgilanadi (8-10 ball), bog’liqlik jihatdan haam yuqori ball beriladi(8-10 ball).
                    <br>
                    <b>Antonim so’zlar:</b> O’xshashlik jihatdan juda past(0-2 ball), bog’liqlik jihatdan juda yuqori(8-10 ball).
                    <br>
                    <b>Aloqasi bo’lmagan so’z juftliklari:</b> O’xshashlik ham bog’liqlik ham juda past ball beriladi (0-2 ball). <br><?="id:".$question->id?>-->
                </td>
            </tr>


        </table>
        <?php ActiveForm::end() ?>


    </div>
</div>
